#Install newrelic
npm install newrelic

#add require statement to hello.js
require("newrelic");

#modify newrelic.js
app_name: [''],
license_key: [''],
