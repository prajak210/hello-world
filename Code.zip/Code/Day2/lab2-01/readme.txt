#To start a simple web server, just type node [script_name.js]

node hello.js
