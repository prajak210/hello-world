# nodejs-train-day-2
Material for training nodejs day 2
