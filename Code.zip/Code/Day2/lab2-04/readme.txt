# Install nginx
# config nginx as reverse proxy for nodejs application
