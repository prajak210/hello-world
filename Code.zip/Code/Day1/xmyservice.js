var express = require("express");

var app = express();

require('rootpath')();
var bodyParser = require('body-parser');
app.use(bodyParser.json());

var session = require('express-session')
app.use(session({ secret: 'keyboard cat', cookie: { maxAge: 300000 }}));

app.get('/',function (req,res) {
  console.log('Hello world');
  res.send('Helle world');
}

);

var MongoClient = require('mongodb').MongoClient;
var dbUrl ="mongodb://localhost:27017/social";
var ObjectID = require('mongodb').ObjectID;
app.post('/contacts/add',function(req,res){
MongoClient.connect(dbUrl,function(err,db){
if(err) res.send(err);
var id = new ObjectID();
var data = req.body;
data["_id"] = id.toHexString();
db.collection('contacts')
.insertOne(data,function(err,result){
db.close();
if(err) res.send(err);
res.send(result);
});
});
});


/*
var centralApi = require('api/centralApi');
var restApi = new centralApi.restApi();
var logger = new centralApi.apiLogger();
var authorize = require('api/security/authorize');
var auth = new authorize();
app.all('/api/*',auth.validateSession,logger.getGuid
  ,logger.writeReqLog,restApi.executeApi,logger.writeResLog);

*/
app.listen(3000);
console.log("My Service is listening to port 3000.");

process.on('uncaughtException', function (err) {
  console.error((new Date).toISOString() + ' uncaughtException:', err.message);
});

