var a = require('./aggregation');
	a.sum(1,2,4,5,6,7);
	console.log(a._sum);
	a.avg(4,2,5,6,7,9,18,11);
	console.log(a._avg);
